<div class="wrapper cover table">
	<div class="center_v center_h shadedout mailbox">
	<h2>ارسال</h2>
	<input type="text" class="formcontrol sendfrom" data='من' id='sendfrom' placeholder='من : قم بادخال ايميلك'>
	<input type="text" class="formcontrol sendto"   data='الى' id='sendto' placeholder='الى : قم بادخال ايميل المرسل الية'>

	<textarea placeholder='سنقوم بارسال رابط الصفحة الى الايميل المرفق , اذا كنت تريد ان ترفق رسالة مع الرابط قم بادخالها'
	class="formcontrol sendbody" ></textarea>
	<input type="submit" class="buttonwhite shadedout" onclick='javascript:return mailBox()' value="أرسال" />
		<input type="submit"value='إغلاق ' class="buttonwhite close" /> 
	
	<div id="sendresult"></div>
	</div>

</div>