<meta charset="utf-8">

<meta http-equiv="content-language" content="ar" />
<meta name="author" content="yourpostalcode.com" >
<meta name="country" content="Egypt" />

<meta name="og:type" content="website" />
<meta name="og:image" content="img/og-img.png" />
<meta name="Description" content="
رقمى البريدى أية , خدمة جديدة لمعرفة رقمك البريدى بسهولة فى اى مكان و بدون بحث يتم تحديد الرقم البريدى بناءً على موقع المستخدم
" />
<meta name="og:keywords" content="
رقم البريد , مكتب البريد, خدمات مكتب البريد , مواعيد مكتب بريد ,
" />
<meta name="author" content="YourPostalCode.com" />
<meta name="og:URL" content="http://yourpostalcode.com" />
<meta name="site-name" content="رقمى البريدى أية ؟">

<!-- //Publisher page attached -->
<!--  <meta property="fb:app_id" content="796734820445134">

 <meta property="article:author" content="https://www.facebook.com/natega.edu">

 <meta property="article:publisher" content="https://www.facebook.com/natega.edu">
 -->