	

	<div id='menu'>
		<ul>
			<li> <a class="link" href="<?php echo base_url(); ?>"> الرئيسية </a></li>
<!-- 			<li> <a class="link" href="#"> رقمى أية </a></li>
			<li> <a class="link" href="#"> بحث </a></li> -->
			<li> <a class="link" href="<?php echo contact_base_url(); ?>"> اتصل بنا </a></li>
		</ul>
	</div>


