
<div class='header  table '>

<?php $this->load->view('menu'); ?>

	<div class="hbody">
		<h1> رقمى البريدى أية ؟ </h1>
		<p class="p1">
			رقمى البريدى أية ,  خدمة جديدة  لمعرفة رقمك البريدى بسهولة فى اى مكان  و بدون بحث يتم تحديد الرقم البريدى بناءً على موقع المستخدم
		</p>
		<a href="<?php echo base_url(); ?>" class="link box-solid" id='rakmy'> رقمى أية ؟</a>

<!-- 		<p class="p2">
			كما يمكنك ايضا استخدام
			<a href="#" class="gosearch link underline"> البحث المتقدم </a> 
			  لمعرفة الرقم البريدى لاى مكان أخر
		</p> -->
	</div>

</div>
